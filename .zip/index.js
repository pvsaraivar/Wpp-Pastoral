const { Client, LocalAuth } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');

const client = new Client({
    authStrategy: new LocalAuth(),
    puppeteer: {
        headless: true,
        args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage']
    }
});

const aguardandoHumano = new Set();

client.on('qr', (qr) => {
    console.log('ATENÇÃO: Copie o link abaixo e cole no seu navegador para ver o QR Code limpo:');
    console.log(`https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(qr)}`);
});

client.on('ready', () => {
    console.log('Robô da pastoral online e operando em formato de menu!');
});

// Exemplo de estrutura para o menu dinâmico com as 9 opções e validação de fora do escopo
client.on('message', async msg => {
    // Ignora mensagens enviadas por grupos ou pelo próprio bot se necessário
    if (msg.fromMe) return;

    const texto = msg.body.trim();

    // Se o usuário mandar uma saudação ou pedir o menu principal
    const opcoesValidas = ['1', '2', '3', '4', '5', '6', '7', '8', '9'];

    if (!opcoesValidas.includes(texto)) {
        // MENSAGEM FORA DO ESCOPO / OPÇÃO INVÁLIDA
        await client.sendMessage(msg.from, 
            '🙏 *Olá! Seja bem-vindo(a) à Secretaria Paroquial.*\n\n' +
            'Não reconheci essa opção. Por favor, envie **apenas o número** correspondente à opção desejada:\n\n' +
            '1️⃣ - Horário de Missa\n' +
            '2️⃣ - Confissões\n' +
            '3️⃣ - Secretaria da Cúria e Contatos\n' +
            '4️⃣ - Batistério\n' +
            '5️⃣ - Tribunal Eclesiástico\n' +
            '6️⃣ - Dom Gregório\n' +
            '7️⃣ - Plano de Pastoral / Pagamento\n' +
            '8️⃣ - Escola Diaconal\n' +
            '9️⃣ - Falar com a coordenação'
        );
        return;
    }

    // Se for a opção 9, ativa o transbordo para atendimento humano
    if (texto === '9') {
        await client.sendMessage(msg.from, '👤 Entendido! Um atendente da nossa equipe irá responder em breve. Aguarde um momento.');
        // Aqui você pode adicionar o número à lista de atendimento humano (ex: aguardandoHumano.add(msg.from))
        return;
    }

    // Para as opções de 1 a 8, você pode buscar a resposta diretamente da sua planilha (puxando a linha correspondente ao número enviado)
    // Exemplo genérico simulando a busca na planilha:
    // const respostaDaPlanilha = dadosDaPlanilha[texto]; 
    // await client.sendMessage(msg.from, respostaDaPlanilha);
});

client.on('message_create', async msg => {
    if (msg.fromMe && msg.body === '/bot') {
        aguardandoHumano.delete(msg.to);
        console.log(`Bot reativado para o chat ${msg.to}`);
    }
});

client.initialize();